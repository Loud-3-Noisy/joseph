---@enum PillEffectType
TSIL.Enums.PillEffectType = {
    NULL = -1,
    POSITIVE = 0,
    NEGATIVE = 1,
    NEUTRAL = 2,
    MODDED = 3
}