---@enum InventoryType
TSIL.Enums.InventoryType = {
	COLLECTIBLE = 1,
	TRINKET = 2
}