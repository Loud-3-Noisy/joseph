---@enum ConversionHeartSubType
TSIL.Enums.ConversionHeartSubType = {
	BLACK = HeartSubType.HEART_BLACK,
	SOUL = HeartSubType.HEART_SOUL,
}
