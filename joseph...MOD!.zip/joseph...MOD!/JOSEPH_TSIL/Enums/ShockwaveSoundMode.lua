---@enum ShockwaveSoundMode
TSIL.Enums.ShockwaveSoundMode = {
    NO_SOUND = 0,
    ON_CREATE = 1,
    LOOP = 2
}