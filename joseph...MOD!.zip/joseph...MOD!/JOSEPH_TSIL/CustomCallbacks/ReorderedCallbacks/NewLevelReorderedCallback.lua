--##use CustomCallbacks/ReorderedCallbacks/GameReorderedLogic.lua
--##POST_NEW_LEVEL_REORDERED
TSIL.__RegisterCustomCallback(TSIL.Enums.CustomCallback.POST_NEW_LEVEL_REORDERED)