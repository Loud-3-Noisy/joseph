--##use CustomCallbacks/ReorderedCallbacks/GameReorderedLogic.lua
--##POST_NEW_ROOM_REORDERED
TSIL.__RegisterCustomCallback(TSIL.Enums.CustomCallback.POST_NEW_ROOM_REORDERED)