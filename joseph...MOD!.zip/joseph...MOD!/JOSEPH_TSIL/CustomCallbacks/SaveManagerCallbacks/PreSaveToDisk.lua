--##PRE_SAVE_MANAGER_SAVE_TO_DISK
TSIL.__RegisterCustomCallback(
    TSIL.Enums.CustomCallback.PRE_SAVE_MANAGER_SAVE_TO_DISK,
    TSIL.Enums.CallbackReturnMode.SKIP_NEXT,
    TSIL.Enums.CallbackOptionalArgType.GENERIC
)