--##POST_ESAU_JR
--##use CustomCallbacks/PlayerCallbacks/EsauJrCallbacks/EsauJrCallbackLogic.lua

TSIL.__RegisterCustomCallback(TSIL.Enums.CustomCallback.POST_ESAU_JR)