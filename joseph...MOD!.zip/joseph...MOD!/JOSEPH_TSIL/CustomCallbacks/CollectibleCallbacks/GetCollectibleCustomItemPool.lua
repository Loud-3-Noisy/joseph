--##POST_GET_COLLECTIBLE_CUSTOM_ITEM_POOL

TSIL.__RegisterCustomCallback(
    TSIL.Enums.CustomCallback.POST_GET_COLLECTIBLE_CUSTOM_ITEM_POOL,
    TSIL.Enums.CallbackReturnMode.NEXT_ARGUMENT,
    TSIL.Enums.CallbackOptionalArgType.GENERIC,
    TSIL.Enums.CallbackOptionalArgType.GENERIC
)